# OES - Order Execution Summary Report - SEC RULE 605(a)(2)

## Instructions for the report renderer

1. Unzip oes.zip to your local machine, creating five files.
1. Open index.html using an up-to-date version of any web browser.
1. Click the button and open the sample.csv file
1. The browser will produce a .pdf file that you can save.
1. Click the button again and open the ng.csv file
1. The new pdf will show the validations violated by ng.csv.
1. Prepare your own .csv file according to the Guide.
